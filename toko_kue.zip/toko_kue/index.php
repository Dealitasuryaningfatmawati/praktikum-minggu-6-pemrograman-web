<?php
require_once "config/database.php";
$page_title = "Sweet Cake — Kue Premium";
$base_path = "";
$query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC LIMIT 6");
include "includes/header.php";
?>
<section class="hero">
    <div class="container">
        <div class="hero-content">
            <span class="eyebrow">✦ PREMIUM HOMEMADE CAKE</span>
            <h1>Maniskan setiap momen dengan Sweet Cake.</h1>
            <p>Katalog kue pilihan dengan tampilan modern, rasa lembut, dan dibuat untuk menemani momen spesialmu.</p>
            <div class="hero-actions">
                <a class="btn" href="produk.php">Jelajahi Katalog →</a>
                <a class="btn btn-light" href="tentang.php">Tentang Sweet Cake</a>
            </div>
        </div>
    </div>
</section>

<section class="section">
<div class="container">
    <div class="section-head">
        <div>
            <h2>Rekomendasi terbaru</h2>
            <p>Pilihan produk yang sedang tersedia di katalog.</p>
        </div>
        <a href="produk.php">Lihat semua →</a>
    </div>
    <div class="grid">
    <?php while ($row = mysqli_fetch_assoc($query)): ?>
        <article class="card product-card">
            <?php if ($row['gambar']): ?>
                <img class="product-image" src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" alt="<?= htmlspecialchars($row['nama']); ?>">
            <?php endif; ?>
            <div class="product-body">
                <span class="badge"><?= htmlspecialchars($row['kategori']); ?></span>
                <h3><?= htmlspecialchars($row['nama']); ?></h3>
                <p><?= htmlspecialchars($row['deskripsi']); ?></p>
                <div class="price">Rp <?= number_format($row['harga'],0,',','.'); ?></div>
                <br>
                <a class="btn btn-small" href="detail.php?id=<?= $row['id']; ?>">Lihat detail</a>
            </div>
        </article>
    <?php endwhile; ?>
    </div>
</div>
</section>
<?php include "includes/footer.php"; ?>
