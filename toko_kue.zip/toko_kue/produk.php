<?php
require_once "config/database.php";
$page_title = "Katalog — Sweet Cake";
$base_path = "";
$keyword = $_GET['keyword'] ?? '';
if ($keyword != '') {
    $keyword_safe = mysqli_real_escape_string($conn, $keyword);
    $query = mysqli_query($conn, "SELECT * FROM produk WHERE nama LIKE '%$keyword_safe%' ORDER BY id DESC");
} else {
    $query = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC");
}
include "includes/header.php";
?>
<div class="page">
<div class="container">
    <div class="page-title">
        <h1>Katalog Sweet Cake</h1>
        <p>Temukan kue favoritmu dengan pencarian sederhana.</p>
    </div>
    <div class="card">
        <form method="GET" class="search-grid">
            <div>
                <label>Cari produk</label>
                <input type="text" name="keyword" placeholder="Contoh: Brownies Coklat" value="<?= htmlspecialchars($keyword); ?>">
            </div>
            <div><label>&nbsp;</label><button class="btn" type="submit">🔎 Cari</button></div>
            <div><label>&nbsp;</label><a class="btn btn-light" href="produk.php">Reset</a></div>
        </form>
    </div>
    <div class="grid">
    <?php if (mysqli_num_rows($query) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($query)): ?>
        <article class="card product-card">
            <?php if ($row['gambar']): ?><img class="product-image" src="uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" alt="<?= htmlspecialchars($row['nama']); ?>"><?php endif; ?>
            <div class="product-body">
                <span class="badge"><?= htmlspecialchars($row['kategori']); ?></span>
                <h3><?= htmlspecialchars($row['nama']); ?></h3>
                <p><?= htmlspecialchars($row['deskripsi']); ?></p>
                <div class="price">Rp <?= number_format($row['harga'],0,',','.'); ?></div>
                <p>Stok tersedia: <strong><?= (int)$row['stok']; ?></strong></p>
                <a class="btn btn-small" href="detail.php?id=<?= $row['id']; ?>">Lihat Detail</a>
            </div>
        </article>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="card empty" style="grid-column:1/-1">Produk dengan kata kunci tersebut belum ditemukan.</div>
    <?php endif; ?>
    </div>
</div>
</div>
<?php include "includes/footer.php"; ?>
