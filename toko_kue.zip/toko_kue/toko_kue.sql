CREATE DATABASE IF NOT EXISTS `toko_kue` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `toko_kue`;

DROP TABLE IF EXISTS `produk`;
DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` (`nama`,`username`,`password`) VALUES
('Administrator','admin','$2y$10$98vbxh4xT65X0Rnc9/L33eWkPdxz8VL4hbvd338D7IILqDOqYj4e6');

CREATE TABLE `produk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `harga` decimal(12,2) NOT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `gambar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `produk` (`nama`,`kategori`,`deskripsi`,`harga`,`stok`,`gambar`) VALUES
('Brownies Coklat','Brownies','Brownies coklat lembut dengan topping coklat premium.',45000,20,'brownies.jpg'),
('Cheese Cake','Cake','Cheese cake lembut dengan rasa keju yang creamy.',65000,15,'cheesecake.jpg'),
('Donat Coklat','Donat','Donat lembut dari bahan kentang asli dengan topping coklat yang manis.',30000,25,'donat.jpg');
