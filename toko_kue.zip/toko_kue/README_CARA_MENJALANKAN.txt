BORA CAKE — BTS PURPLE EDITION
===============================

Project ini adalah modifikasi dari project toko_kue awal.
Konsep CRUD dari project dosen dipertahankan, kemudian ditambahkan:
1. Tema BTS-inspired / purple premium.
2. Login admin dan logout.
3. Dashboard admin yang lebih modern.
4. Search, filter, pagination tetap dipertahankan.
5. Upload gambar produk tetap dipertahankan.
6. Halaman publik dibuat lebih premium dan responsif.
7. Statistik dashboard: total produk, kategori, dan stok.
8. Validasi upload gambar tetap: JPG/JPEG/PNG/WEBP maksimal 2 MB.

STACK
-----
- VS Code
- Laragon
- PHP
- MySQL/MariaDB
- phpMyAdmin

CARA MENJALANKAN
----------------
1. Extract folder "toko_kue" ke:
   C:\laragon\www\

   Hasil akhirnya:
   C:\laragon\www\toko_kue\index.php

2. Buka Laragon.
   Start Apache dan MySQL.

3. Buka phpMyAdmin:
   http://localhost/phpmyadmin/

4. Buat database bernama:
   toko_kue

5. Klik database toko_kue > Import.
   Pilih file:
   toko_kue/toko_kue.sql

6. Jalankan:
   http://localhost/toko_kue/

LOGIN ADMIN
-----------
URL:
http://localhost/toko_kue/auth/login.php

Username:
admin

Password:
admin123

HALAMAN ADMIN
-------------
Dashboard:
http://localhost/toko_kue/admin/

Manajemen produk:
http://localhost/toko_kue/admin/produk.php

KONSEP CRUD YANG DIPERTAHANKAN
-------------------------------
CREATE  = admin/tambah.php + admin/proses_produk.php
READ    = index.php, produk.php, detail.php, admin/produk.php
UPDATE  = admin/edit.php + admin/proses_produk.php
DELETE  = admin/hapus.php
LOGIN   = auth/login.php + auth/proses_login.php
LOGOUT  = admin/logout.php
DATABASE= config/database.php + toko_kue.sql

CATATAN
-------
Tema menggunakan gaya BTS-inspired (ungu, hitam, pink, glow, star/dot pattern)
tanpa mengambil logo resmi atau aset berhak cipta. Jadi tetap aman untuk tugas
dan bisa dikembangkan lagi di Canva/Figma.

Jika setelah import database muncul error koneksi, cek:
- Laragon sudah Start MySQL.
- Nama database = toko_kue.
- config/database.php menggunakan:
  host = localhost
  user = root
  password = ""
  database = toko_kue

Project sudah dicek dengan PHP lint dan seluruh file PHP tidak memiliki
syntax error.
