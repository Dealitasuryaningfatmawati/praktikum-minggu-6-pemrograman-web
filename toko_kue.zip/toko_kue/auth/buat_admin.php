<?php
require_once "../config/database.php";
$nama = "Administrator";
$username = "admin";
$password = "admin123";
$password_hash = password_hash($password, PASSWORD_DEFAULT);

$check = mysqli_query($conn, "SELECT id FROM admin WHERE username='admin' LIMIT 1");
if (mysqli_num_rows($check) > 0) {
    echo "Akun admin sudah tersedia. Silakan login dengan username admin dan password admin123.";
    exit;
}
$query = mysqli_query($conn, "INSERT INTO admin (nama, username, password) VALUES ('$nama', '$username', '$password_hash')");
echo $query ? "Admin berhasil dibuat. Username: admin | Password: admin123" : "Gagal membuat admin: ".mysqli_error($conn);
