<?php
session_start();
if (isset($_SESSION['admin_id'])) { header("Location: ../admin/index.php"); exit; }
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Login Admin — Sweet Cake</title><link rel="stylesheet" href="../assets/style.css">
</head>
<body class="auth-page">
<div class="auth-shell">
    <section class="auth-visual">
        <div class="auth-logo">SC</div>
        <h1>Kelola Sweet Cake dengan lebih elegan.</h1>
        <p>Panel admin untuk mengelola katalog produk secara cepat, aman, dan terstruktur.</p>
        <ul class="feature-list">
            <li><span>✓</span> CRUD produk tetap digunakan</li>
            <li><span>✓</span> Upload & kelola gambar</li>
            <li><span>✓</span> Dashboard katalog</li>
        </ul>
    </section>
    <section class="auth-form">
        <h2>Selamat datang kembali 👋</h2>
        <p class="sub">Masuk ke dashboard administrator Sweet Cake.</p>
        <?php if ($error): ?><div class="alert error"><?= htmlspecialchars($error); ?></div><?php endif; ?>
        <form action="proses_login.php" method="POST">
            <label>Username</label>
            <input type="text" name="username" placeholder="Masukkan username" autocomplete="username" required>
            <label>Password</label>
            <input type="password" name="password" placeholder="Masukkan password" autocomplete="current-password" required>
            <button class="btn" type="submit" style="width:100%">Masuk ke Dashboard →</button>
        </form>
        <div class="divider"></div>
        <p class="helper">Demo akun awal: <strong>admin</strong> / <strong>admin123</strong></p>
        <a href="../index.php">← Kembali ke website</a>
    </section>
</div>
</body>
</html>
