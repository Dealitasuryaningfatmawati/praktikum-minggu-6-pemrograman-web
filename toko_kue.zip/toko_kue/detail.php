<?php
require_once "config/database.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
$produk = mysqli_fetch_assoc($query);
if (!$produk) { die("Produk tidak ditemukan."); }
$page_title = $produk['nama'] . " — Sweet Cake";
$base_path = "";
include "includes/header.php";
?>
<div class="page">
<div class="container">
    <div class="card detail">
        <div>
            <?php if ($produk['gambar']): ?>
                <img class="detail-image" src="uploads/produk/<?= htmlspecialchars($produk['gambar']); ?>" alt="<?= htmlspecialchars($produk['nama']); ?>">
            <?php endif; ?>
        </div>
        <div>
            <span class="badge"><?= htmlspecialchars($produk['kategori']); ?></span>
            <h1><?= htmlspecialchars($produk['nama']); ?></h1>
            <p><?= nl2br(htmlspecialchars($produk['deskripsi'])); ?></p>
            <div class="detail-price">Rp <?= number_format($produk['harga'],0,',','.'); ?></div>
            <div class="info-row"><span class="badge">Stok: <?= (int)$produk['stok']; ?></span><span class="badge">Fresh product</span></div>
            <a class="btn" href="produk.php">← Kembali ke katalog</a>
        </div>
    </div>
</div>
</div>
<?php include "includes/footer.php"; ?>
