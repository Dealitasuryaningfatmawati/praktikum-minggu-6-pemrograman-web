<?php
$page_title = "Tentang — Sweet Cake";
$base_path = "";
include "includes/header.php";
?>
<div class="page">
<div class="container">
    <div class="dashboard-hero">
        <span class="eyebrow">ABOUT SWEET CAKE</span>
        <h1 style="margin-top:15px">Kue sederhana, momen luar biasa.</h1>
        <p>Sweet Cake adalah konsep toko kue yang menghadirkan katalog digital sederhana dengan pengalaman pengguna yang bersih dan modern.</p>
    </div>
    <div class="grid" style="margin-top:22px">
        <div class="card"><span class="badge">01</span><h2>Fresh</h2><p>Produk ditampilkan lengkap dengan kategori, harga, stok, deskripsi, dan gambar.</p></div>
        <div class="card"><span class="badge">02</span><h2>Simple</h2><p>Pelanggan dapat mencari produk dan membuka detail produk dengan mudah.</p></div>
        <div class="card"><span class="badge">03</span><h2>Managed</h2><p>Admin memiliki panel khusus untuk menambah, mengedit, menghapus, dan mencari katalog.</p></div>
    </div>
    <div class="card">
        <h2>Kontak</h2>
        <p>WhatsApp: 08xxxxxxxxxx</p>
        <p>Instagram: @sweetcake</p>
    </div>
</div>
</div>
<?php include "includes/footer.php"; ?>
