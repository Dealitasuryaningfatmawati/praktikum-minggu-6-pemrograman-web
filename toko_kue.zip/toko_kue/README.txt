# Sweet Cake — CRUD + Login Logout (Soft Blue)

Project ini merupakan modifikasi dari project CRUD dosen. Konsep utama tetap:
- PHP native + MySQL/MariaDB
- tabel `produk`
- CRUD tambah, tampil, edit, hapus
- pencarian, filter, pagination
- upload gambar
- login/logout admin

Tambahan:
- UI premium soft blue
- halaman login modern
- dashboard admin
- statistik produk/kategori/stok
- responsive mobile
- flash message
- navbar dinamis
- detail katalog

## Cara menjalankan di Laragon

1. Extract folder `toko_kue` ke:
   `C:\laragon\www\`
2. Jalankan Apache dan MySQL dari Laragon.
3. Buka `http://localhost/phpmyadmin`.
4. Buat/import database dengan file `toko_kue.sql`.
5. Pastikan folder:
   `toko_kue/uploads/produk/`
   tetap ada dan dapat ditulis.
6. Buka:
   `http://localhost/toko_kue/`
7. Login admin:
   Username: `admin`
   Password: `admin123`
8. Setelah login, buka Dashboard untuk mencoba CRUD.

Jika akun admin belum ada, buka:
`http://localhost/toko_kue/auth/buat_admin.php`

Setelah akun berhasil dibuat, demi keamanan hapus/rename file `buat_admin.php`.

## Struktur penting

- `index.php` — halaman utama
- `produk.php` — katalog
- `detail.php` — detail produk
- `auth/login.php` — login
- `auth/proses_login.php` — proses login
- `admin/index.php` — dashboard
- `admin/produk.php` — CRUD/list produk
- `admin/tambah.php` — tambah
- `admin/edit.php` — edit
- `admin/hapus.php` — hapus
- `admin/proses_produk.php` — proses CRUD
- `admin/logout.php` — logout
- `config/database.php` — koneksi database
- `toko_kue.sql` — database
- `assets/style.css` — desain soft blue

## Catatan
Kode CRUD inti dari project awal tetap dipertahankan pada `admin/proses_produk.php`, `admin/hapus.php`, struktur tabel `produk`, dan alur login/logout. Modifikasi utama ada pada tampilan, dashboard, navigasi, dan pengalaman pengguna.
