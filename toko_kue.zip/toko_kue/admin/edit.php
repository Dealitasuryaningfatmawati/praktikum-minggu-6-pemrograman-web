<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id = $id");
$produk = mysqli_fetch_assoc($query);
if (!$produk) die("Produk tidak ditemukan.");
$page_title = "Edit Produk — Sweet Cake";
$base_path = "../";
include "../includes/header.php";
?>
<div class="page"><div class="container">
<div class="page-title"><h1>Edit Produk</h1><p>Perbarui data katalog tanpa mengubah struktur CRUD utama.</p></div>
<?php include "../includes/flash.php"; ?>
<div class="card">
<form action="proses_produk.php" method="POST" enctype="multipart/form-data">
<input type="hidden" name="aksi" value="edit"><input type="hidden" name="id" value="<?= $produk['id']; ?>">
<label>Nama Produk</label><input type="text" name="nama" value="<?= htmlspecialchars($produk['nama']); ?>" required>
<label>Kategori</label><select name="kategori" required>
<option value="Cake" <?= $produk['kategori']=='Cake'?'selected':''; ?>>Cake</option>
<option value="Brownies" <?= $produk['kategori']=='Brownies'?'selected':''; ?>>Brownies</option>
<option value="Donat" <?= $produk['kategori']=='Donat'?'selected':''; ?>>Donat</option>
</select>
<label>Deskripsi</label><textarea name="deskripsi" rows="5" required><?= htmlspecialchars($produk['deskripsi']); ?></textarea>
<label>Harga</label><input type="number" name="harga" min="0" value="<?= $produk['harga']; ?>" required>
<label>Stok</label><input type="number" name="stok" min="0" value="<?= $produk['stok']; ?>" required>
<label>Ganti Gambar</label><input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp">
<?php if($produk['gambar']): ?><p class="helper">Gambar saat ini:</p><img src="../uploads/produk/<?= htmlspecialchars($produk['gambar']); ?>" style="width:180px;height:130px;object-fit:cover;border-radius:14px;margin-bottom:18px"><?php endif; ?>
<div class="form-actions"><button type="submit" class="btn">Simpan Perubahan</button><a href="produk.php" class="btn btn-light">Batal</a></div>
</form>
</div></div></div>
<?php include "../includes/footer.php"; ?>
