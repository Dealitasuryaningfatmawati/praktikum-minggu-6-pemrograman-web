<?php
require_once "../includes/auth.php";
$page_title = "Tambah Produk — Sweet Cake";
$base_path = "../";
include "../includes/header.php";
?>
<div class="page"><div class="container">
<div class="page-title"><h1>Tambah Produk</h1><p>Masukkan produk baru ke katalog Sweet Cake.</p></div>
<?php include "../includes/flash.php"; ?>
<div class="card">
<form action="proses_produk.php" method="POST" enctype="multipart/form-data">
<input type="hidden" name="aksi" value="tambah">
<label>Nama Produk</label><input type="text" name="nama" placeholder="Contoh: Brownies Coklat" required>
<label>Kategori</label><select name="kategori" required><option value="">Pilih kategori</option><option value="Cake">Cake</option><option value="Brownies">Brownies</option><option value="Donat">Donat</option></select>
<label>Deskripsi</label><textarea name="deskripsi" rows="5" placeholder="Deskripsikan produk..." required></textarea>
<label>Harga</label><input type="number" name="harga" min="0" placeholder="45000" required>
<label>Stok</label><input type="number" name="stok" min="0" placeholder="20" required>
<label>Gambar Produk</label><input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp">
<p class="helper">Format: JPG, JPEG, PNG, WEBP. Maksimal 2 MB.</p>
<div class="form-actions"><button type="submit" class="btn">Simpan Produk</button><a href="produk.php" class="btn btn-light">Batal</a></div>
</form>
</div></div></div>
<?php include "../includes/footer.php"; ?>
