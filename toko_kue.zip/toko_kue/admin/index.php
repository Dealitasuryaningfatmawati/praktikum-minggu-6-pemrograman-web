<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
$page_title = "Dashboard Admin — Sweet Cake";
$base_path = "../";

$total_produk = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM produk"));
$total_kategori = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT kategori) AS total FROM produk"));
$total_stok = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(stok),0) AS total FROM produk"));
$latest = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC LIMIT 5");
include "../includes/header.php";
?>
<div class="page">
<div class="container">
    <div class="dashboard-hero">
        <span class="eyebrow">ADMIN CONTROL CENTER</span>
        <h1>Halo, <?= htmlspecialchars($_SESSION['admin_nama']); ?> 👋</h1>
        <p>Kelola katalog Sweet Cake dari satu dashboard yang rapi dan responsif.</p>
    </div>
    <div class="stats">
        <div class="card stat"><div class="stat-label">Total Produk</div><div class="stat-value"><?= $total_produk['total']; ?></div></div>
        <div class="card stat"><div class="stat-label">Kategori</div><div class="stat-value"><?= $total_kategori['total']; ?></div></div>
        <div class="card stat"><div class="stat-label">Total Stok</div><div class="stat-value"><?= $total_stok['total']; ?></div></div>
    </div>
    <div class="section-head">
        <div><h2>Produk terbaru</h2><p>Data terakhir yang tersimpan di database.</p></div>
        <a class="btn" href="produk.php">Kelola Produk +</a>
    </div>
    <div class="card">
        <div class="table-wrap">
        <table class="data-table">
            <tr><th>Produk</th><th>Kategori</th><th>Harga</th><th>Stok</th></tr>
            <?php while ($row = mysqli_fetch_assoc($latest)): ?>
            <tr>
                <td><strong><?= htmlspecialchars($row['nama']); ?></strong></td>
                <td><span class="badge"><?= htmlspecialchars($row['kategori']); ?></span></td>
                <td>Rp <?= number_format($row['harga'],0,',','.'); ?></td>
                <td><?= (int)$row['stok']; ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        </div>
    </div>
</div>
</div>
<?php include "../includes/footer.php"; ?>
