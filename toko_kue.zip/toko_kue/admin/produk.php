<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
$page_title = "Kelola Produk — Sweet Cake";
$base_path = "../";

$keyword = $_GET['keyword'] ?? '';
$kategori = $_GET['kategori'] ?? '';
$where = [];
if ($keyword != '') {
    $keyword_safe = mysqli_real_escape_string($conn, $keyword);
    $where[] = "nama LIKE '%$keyword_safe%'";
}
if ($kategori != '') {
    $kategori_safe = mysqli_real_escape_string($conn, $kategori);
    $where[] = "kategori = '$kategori_safe'";
}
$where_sql = count($where) > 0 ? "WHERE " . implode(" AND ", $where) : "";

$per_page = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $per_page;

$count_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM produk $where_sql");
$count_data = mysqli_fetch_assoc($count_query);
$total_data = $count_data['total'];
$total_page = $total_data > 0 ? ceil($total_data / $per_page) : 1;

$query = mysqli_query($conn, "SELECT * FROM produk $where_sql ORDER BY id DESC LIMIT $per_page OFFSET $offset");
include "../includes/header.php";
?>
<div class="page">
<div class="container">
    <div class="page-title">
        <h1>Pengelolaan Katalog</h1>
        <p>Tambah, cari, edit, dan hapus produk dari database.</p>
    </div>
    <?php include "../includes/flash.php"; ?>
    <div style="margin-bottom:18px"><a href="tambah.php" class="btn">＋ Tambah Produk</a></div>
    <div class="card">
        <form method="GET" class="search-grid">
            <div><label>Pencarian</label><input type="text" name="keyword" placeholder="Cari nama produk..." value="<?= htmlspecialchars($keyword); ?>"></div>
            <div><label>Kategori</label><select name="kategori">
                <option value="">Semua Kategori</option>
                <option value="Cake" <?= $kategori=='Cake'?'selected':''; ?>>Cake</option>
                <option value="Brownies" <?= $kategori=='Brownies'?'selected':''; ?>>Brownies</option>
                <option value="Donat" <?= $kategori=='Donat'?'selected':''; ?>>Donat</option>
            </select></div>
            <div><label>&nbsp;</label><button type="submit" class="btn">Cari</button></div>
            <div><label>&nbsp;</label><a href="produk.php" class="btn btn-light">Reset</a></div>
        </form>
    </div>
    <div class="card">
        <div class="table-wrap">
        <table class="data-table">
            <tr><th>No</th><th>Gambar</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Aksi</th></tr>
            <?php $no=$offset+1; while ($row=mysqli_fetch_assoc($query)): ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?php if($row['gambar']): ?><img src="../uploads/produk/<?= htmlspecialchars($row['gambar']); ?>" alt=""><?php else: ?>—<?php endif; ?></td>
                <td><strong><?= htmlspecialchars($row['nama']); ?></strong></td>
                <td><span class="badge"><?= htmlspecialchars($row['kategori']); ?></span></td>
                <td>Rp <?= number_format($row['harga'],0,',','.'); ?></td>
                <td><?= (int)$row['stok']; ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-small btn-warning">Edit</a>
                    <a href="hapus.php?id=<?= $row['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('Yakin ingin menghapus produk ini?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
            <?php if ($total_data==0): ?><tr><td colspan="7" class="empty">Belum ada produk yang cocok.</td></tr><?php endif; ?>
        </table>
        </div>
        <div class="pagination">
        <?php for($i=1;$i<=$total_page;$i++): ?>
            <a class="<?= $i==$page?'active':''; ?>" href="?page=<?= $i; ?>&keyword=<?= urlencode($keyword); ?>&kategori=<?= urlencode($kategori); ?>"><?= $i; ?></a>
        <?php endfor; ?>
        </div>
    </div>
</div>
</div>
<?php include "../includes/footer.php"; ?>
