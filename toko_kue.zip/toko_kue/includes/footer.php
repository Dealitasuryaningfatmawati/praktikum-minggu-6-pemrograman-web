
<footer class="site-footer">
    <div class="container footer-flex">
        <strong>Sweet Cake</strong>
        <span>Fresh taste · Soft moments · Made with care</span>
    </div>
</footer>
</body>
</html>
