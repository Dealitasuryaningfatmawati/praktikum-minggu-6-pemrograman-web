<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title ?? 'Sweet Cake'); ?></title>
    <link rel="stylesheet" href="<?= htmlspecialchars($base_path ?? '') ?>assets/style.css">
</head>
<body>
<nav class="navbar">
    <div class="container nav-inner">
        <a class="brand" href="<?= htmlspecialchars($base_path ?? '') ?>index.php">
            <span class="brand-mark">SC</span> Sweet Cake
        </a>
        <a href="<?= htmlspecialchars($base_path ?? '') ?>index.php">Beranda</a>
        <a href="<?= htmlspecialchars($base_path ?? '') ?>produk.php">Katalog</a>
        <a href="<?= htmlspecialchars($base_path ?? '') ?>tentang.php">Tentang</a>
        <?php if (isset($_SESSION['admin_id'])): ?>
            <a href="<?= htmlspecialchars($base_path ?? '') ?>admin/index.php">Dashboard</a>
            <a class="nav-logout" href="<?= htmlspecialchars($base_path ?? '') ?>admin/logout.php">Keluar</a>
        <?php else: ?>
            <a href="<?= htmlspecialchars($base_path ?? '') ?>auth/login.php">Admin</a>
        <?php endif; ?>
    </div>
</nav>
